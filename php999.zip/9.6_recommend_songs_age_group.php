<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Most popular song during specific age group</title>
</head>

<h2 align = "center"> Most popular song during specific age group </h2>

<body>

<?php

$conn = oci_connect('yw0', 'DBdb1234', 'oracle.cise.ufl.edu:1521/orcl');
session_start();

$recommend = 	"select song.*
		from song,
		(select orders.song_id as oid
		from customer, orders
		where customer.age >= 20 and customer.age <= 30 and customer.username = orders.customer
		group by orders.song_id
		order by count(*) desc)
		where song.id = oid";

$sss = oci_parse($conn, $recommend);

//oci_bind_by_name($sss, ':searchprice111', $_SESSION['searchprice']);
        
oci_execute($sss); 

?>


<?php

echo "<table width='300' border='2' align = "center" >

	<tr>

	<td width = "100"> No. </td>
	<td width = "200"> Singer Name </td>

	</tr>";

$i = 1;

while ($i<11){

	while ($row = oci_fetch_array($sss, OCI_BOTH)) {

	    echo "<tr>";

	    echo "<td>" . $i	   	. "</td>";
	    echo "<td>" . $row['NAME']  . "</td>";

	    echo "</tr>";

	}

	$i++;
}

echo "</table>";
    
?>

</body>
</html>
