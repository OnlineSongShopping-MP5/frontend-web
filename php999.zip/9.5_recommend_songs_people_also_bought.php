<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>People bought these songs also bought</title>
</head>

<h2 align = "center"> People bought these songs also bought </h2>

<body>

<?php

$conn = oci_connect('yw0', 'DBdb1234', 'oracle.cise.ufl.edu:1521/orcl');
session_start();

$recommend = 	"select * 
		from
		(select song.*
		from song,
		(select distinct orders.song_id
		from orders,
		(select distinct o2.customer
		from orders o1, orders o2
		where o1.customer = 'user0010' and o2.song_id = o1.song_id and o2.customer != 'user0010') c
		where orders.customer = c.customer) o
		where song.id = o.song_id
		order by song.avg_rate desc)
		where rownum <= 10";

$sss = oci_parse($conn, $recommend);

//oci_bind_by_name($sss, ':searchprice111', $_SESSION['searchprice']);
        
oci_execute($sss); 

?>


<?php

echo "<table width='300' border='2' align = "center" >

	<tr>

	<td width = "100"> No. </td>
	<td width = "200"> Singer Name </td>

	</tr>";

$i = 1;

while ($i<11){

	while ($row = oci_fetch_array($sss, OCI_BOTH)) {

	    echo "<tr>";

	    echo "<td>" . $i	   	. "</td>";
	    echo "<td>" . $row['NAME']  . "</td>";

	    echo "</tr>";

	}

	$i++;
}

echo "</table>";
    
?>

</body>
</html>
