<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Top Ten Songs</title>
</head>

<h2 align = "center"> Top Ten Songs from Our Database </h2>

<body>

<?php

$conn = oci_connect('yw0', 'DBdb1234', 'oracle.cise.ufl.edu:1521/orcl');
session_start();

$sss = oci_parse($conn, "Select Name from (Select title from song order by download desc) where rownum <= 10");

//oci_bind_by_name($sss, ':searchprice111', $_SESSION['searchprice']);
        
oci_execute($sss); 

?>


<?php

echo "<table width='300' border='2' align = "center" >

	<tr>

	<td width = "100"> Rank </td>
	<td width = "200"> Singer Name </td>

	</tr>";

$i = 1;

while ($i<11){

	while ($row = oci_fetch_array($sss, OCI_BOTH)) {

	    echo "<tr>";

	    echo "<td>" . $i	   	. "</td>";
	    echo "<td>" . $row['NAME']  . "</td>";

	    echo "</tr>";

	}

	$i++;
}

echo "</table>";
    
?>

</body>
</html>
