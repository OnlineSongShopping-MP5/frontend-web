<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Recommend songs based on the singers</title>
</head>

<h2 align = "center"> Recommend songs based on the singers </h2>

<body>

<?php

$conn = oci_connect('yw0', 'DBdb1234', 'oracle.cise.ufl.edu:1521/orcl');
session_start();

$recommend = 	"select *
		from song
		where song.singer_id = 
		(select fs from
		(select song.singer_id as fs
		from orders, song
		where orders.customer = 'user0010' and orders.song_id = song.id and orders.paid = 1
		group by song.singer_id
		order by count(*) DESC)
		where rownum = 1)
		and rownum <= 10
		order by song.avg_rate desc;";

$sss = oci_parse($conn, $recommend);

//oci_bind_by_name($sss, ':searchprice111', $_SESSION['searchprice']);
        
oci_execute($sss); 

?>


<?php

echo "<table width='300' border='2' align = "center" >

	<tr>

	<td width = "100"> No. </td>
	<td width = "200"> Singer Name </td>

	</tr>";

$i = 1;

while ($i<11){

	while ($row = oci_fetch_array($sss, OCI_BOTH)) {

	    echo "<tr>";

	    echo "<td>" . $i	   	. "</td>";
	    echo "<td>" . $row['NAME']  . "</td>";

	    echo "</tr>";

	}

	$i++;
}

echo "</table>";
    
?>

</body>
</html>
