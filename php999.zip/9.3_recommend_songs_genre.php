<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Recommend songs based on the genre</title>
</head>

<h2 align = "center"> Recommend songs based on the genres </h2>

<body>

<?php

$conn = oci_connect('yw0', 'DBdb1234', 'oracle.cise.ufl.edu:1521/orcl');
session_start();

$recommend = 	"select * from song where song.genre_id = 
			(select fg from
				(select song.genre_id as fg
				from orders, song
				where orders.customer = 'user0006' and orders.song_id = song.id
				group by song.genre_id
				order by count(*) DESC)
			where rownum = 1) 
		and rownum <= 10
		order by song.avg_rate desc;";

$sss = oci_parse($conn, $recommend);

//oci_bind_by_name($sss, ':searchprice111', $_SESSION['searchprice']);
        
oci_execute($sss); 

?>


<?php

echo "<table width='300' border='2' align = "center" >

	<tr>

	<td width = "100"> Rank </td>
	<td width = "200"> Singer Name </td>

	</tr>";

$i = 1;

while ($i<11){

	while ($row = oci_fetch_array($sss, OCI_BOTH)) {

	    echo "<tr>";

	    echo "<td>" . $i	   	. "</td>";
	    echo "<td>" . $row['NAME']  . "</td>";

	    echo "</tr>";

	}

	$i++;
}

echo "</table>";
    
?>

</body>
</html>
